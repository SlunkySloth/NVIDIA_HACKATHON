def handle(db, event):
    with db:
        db.execute("INSERT INTO subscriptions(entity, status, version) VALUES (?, ?, ?) ON CONFLICT(entity) DO UPDATE SET status=excluded.status, version=excluded.version WHERE excluded.version > subscriptions.version", (event["entity_id"], event["payload"]["status"], event["payload"]["version"]))
    return {"accepted": True}
