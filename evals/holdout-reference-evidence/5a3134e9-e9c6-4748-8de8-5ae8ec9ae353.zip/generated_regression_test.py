def test_reported_incident(client):
    response = client.post('/webhook', json={'kind': 'delivery', 'sequence': 0, 'event_id': 'update_a', 'entity_id': 'account_c', 'event_type': 'subscription.updated', 'payload': {'version': 4, 'status': 'cancelled'}, 'arrival_time': '2026-09-29T12:00:00Z'})
    assert response.status_code == 200
    response = client.post('/webhook', json={'kind': 'delivery', 'sequence': 1, 'event_id': 'update_b', 'entity_id': 'account_c', 'event_type': 'subscription.updated', 'payload': {'version': 4, 'status': 'active'}, 'arrival_time': '2026-09-29T12:00:00Z'})
    assert response.status_code == 200
    assert client.get('/state').json() == {'account_c': {'version': 4, 'status': 'cancelled'}}
