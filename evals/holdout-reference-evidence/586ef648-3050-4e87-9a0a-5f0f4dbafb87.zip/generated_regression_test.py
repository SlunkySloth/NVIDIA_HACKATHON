def test_reported_incident(client):
    response = client.post('/webhook', json={'kind': 'delivery', 'sequence': 0, 'event_id': 'purchase_retry_91', 'entity_id': 'customer_91', 'event_type': 'purchase.succeeded', 'payload': {'credits': 37}, 'arrival_time': '2026-09-29T12:00:00Z'})
    assert response.status_code == 200
    response = client.post('/__replay/restart')
    assert response.status_code == 200
    response = client.post('/webhook', json={'kind': 'delivery', 'sequence': 2, 'event_id': 'purchase_retry_91', 'entity_id': 'customer_91', 'event_type': 'purchase.succeeded', 'payload': {'credits': 37}, 'arrival_time': '2026-09-29T12:00:00Z'})
    assert response.status_code == 200
    assert client.get('/state').json() == {'customer_91': 54}
