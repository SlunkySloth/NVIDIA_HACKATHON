def test_reported_incident(client):
    response = client.post('/webhook', json={'kind': 'delivery', 'sequence': 0, 'event_id': 'purchase_equal_a', 'entity_id': 'customer_42', 'event_type': 'purchase.succeeded', 'payload': {'credits': 45}, 'arrival_time': '2026-09-29T12:00:00Z'})
    assert response.status_code == 200
    response = client.post('/webhook', json={'kind': 'delivery', 'sequence': 1, 'event_id': 'purchase_equal_b', 'entity_id': 'customer_42', 'event_type': 'purchase.succeeded', 'payload': {'credits': 45}, 'arrival_time': '2026-09-29T12:00:00Z'})
    assert response.status_code == 200
    response = client.post('/webhook', json={'kind': 'delivery', 'sequence': 2, 'event_id': 'purchase_equal_a', 'entity_id': 'customer_42', 'event_type': 'purchase.succeeded', 'payload': {'credits': 45}, 'arrival_time': '2026-09-29T12:00:00Z'})
    assert response.status_code == 200
    assert client.get('/state').json() == {'customer_42': 103}
