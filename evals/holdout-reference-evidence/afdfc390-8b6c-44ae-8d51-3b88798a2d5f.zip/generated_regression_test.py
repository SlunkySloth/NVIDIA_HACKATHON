def test_reported_incident(client):
    response = client.post('/webhook', json={'kind': 'delivery', 'sequence': 0, 'event_id': 'payment_b', 'entity_id': 'order_b', 'event_type': 'order.paid', 'payload': {}, 'arrival_time': '2026-09-29T12:00:00Z'})
    assert response.status_code == 200
    response = client.post('/webhook', json={'kind': 'delivery', 'sequence': 1, 'event_id': 'payment_a', 'entity_id': 'order_a', 'event_type': 'order.paid', 'payload': {}, 'arrival_time': '2026-09-29T12:00:00Z'})
    assert response.status_code == 200
    assert client.get('/state').json() == {'order_a': 4, 'order_b': 1}
