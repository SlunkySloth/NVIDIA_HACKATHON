def handle(db, event):
    with db:
        inserted = db.execute("INSERT OR IGNORE INTO processed(event_id) VALUES (?)", (event["event_id"],)).rowcount
        if inserted:
            db.execute("INSERT INTO balances(entity, value) VALUES (?, ?) ON CONFLICT(entity) DO UPDATE SET value=value+excluded.value", (event["entity_id"], 1))
    return {"accepted": True}
