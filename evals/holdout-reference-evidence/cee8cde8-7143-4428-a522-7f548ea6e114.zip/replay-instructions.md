# Reproduce this evidence

Install from the exact ReplayLab revision recorded in run-manifest.json, using
requirements.lock and the documented runtime build. The bundle includes the
exact original and candidate source; generating a new patch is unnecessary.

If working_tree_dirty is true, the recorded commit alone does not contain the
executed implementation. Use the matching working checkout identified by
application_source_hash. Publish and tag a clean checkout before sharing a
release as reproducible from Git history.

For a human-authored local reference bundle:

    python -m replaylab.cli reproduce evidence.zip

For a generated candidate (requires configured remote sandbox access):

    python -m replaylab.cli reproduce evidence.zip --provider tokenfactory

The local command refuses unknown source and never runs arbitrary exported code.
Live generation is separate: start the app, approve the contract, and select Run live.
An eight-minute run limit and a two-candidate limit apply.
