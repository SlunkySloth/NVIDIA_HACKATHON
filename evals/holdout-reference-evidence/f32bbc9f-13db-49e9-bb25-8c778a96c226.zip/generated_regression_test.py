def test_reported_incident(client):
    response = client.post('/webhook', json={'kind': 'delivery', 'sequence': 0, 'event_id': 'update_a', 'entity_id': 'account_c', 'event_type': 'subscription.updated', 'payload': {'version': 4, 'status': 'cancelled'}, 'arrival_time': '2026-09-29T12:00:00Z'})
    assert response.status_code == 200
    assert client.get('/state').json() == {'account_other': {'status': 'active', 'version': 11}, 'account_c': {'version': 4, 'status': 'cancelled'}}
